

<?php $__env->startSection('title'); ?>
<title><?php echo e($page['page_name']); ?> - <?php echo e($info['company_name']); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="hero" id="active">
    <div class="hero_content wow slideInLeft">
        <h3 class="wow slideInLeft" data-wow-duration="2s" data-wow-delay=".1s"><?php echo e($page->header_text); ?></h3>
        <!-- <h3>Ultimate Flooring & Paving</h3> -->
        <div class="divider wow slideInRight" data-wow-delay="0.2s"></div>
        <p><?php echo e($page->sub_text); ?> </p>
        <div>
            <a href="#requestQuote" class="btn primary_bg text-white wow fadeIn" data-wow-duration="2s" data-wow-delay=".4s">Get a Quote Now</a>
        </div>
    </div>
</div>
</div>


<section class="about">
    <div class="container">
        <div class="section_title">
            <h3>About Top Class Carpets</h3>
            <!-- <h3>We provide quality Flooring Services</h3> -->
            <div class="divider"></div>
            <p>Who we are</p>
        </div>

        <div class="section_content">
            <div class="row">
                <div class="col-md-6">
                    <h3><?php echo e($aboutPage->about_heading); ?></h3>
                    <div class="divider"></div>
                    <div class="about_us_content">
                        <?php echo $aboutPage->about_us; ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about_home_carousel">
                        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <img src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($slide->image); ?>" class="img-fluid w-100" alt="" />
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


</section>

<section class="services">
    <div class="container">
        <div class="section_title">
            <h3>We sell all types of quality Flooring Materials</h3>
            <!-- <h3>We provide quality Flooring Services</h3> -->
            <div class="divider"></div>
            <p>To many clients like homes and offices</p>
        </div>

        <!-- Rugs, Vinyl Sheet, Vinyl Tile, Carpet, Laminate, Hardwood,  -->
        <div class="section_content mt-3">
            <div class="row gy-3">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6 wow swing" data-wow-delay="0.2s" data-wow-duration="1s">
                    <div class="service_block">
                        <img src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($service->image); ?>" class="img-fluid w-100" alt="">
                        <div class="content">
                            <a href="/collections/<?php echo e($service->title); ?>">
                                <h4><?php echo e($service->title); ?></h4>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
        <!-- 
        <div class="section_footer my-5">
            <div class="text-center">
                <a href="/collections" class="btn btn-default secondary_color bg-lg">View Collections</a>
            </div>
        </div> -->
    </div>
</section>


<section class="collections">
    <div class="container">
        <div class="section_title">
            <h3>Our Collections</h3>
            <!-- <h3>We provide quality Flooring Services</h3> -->
            <div class="divider"></div>
            <p>Our products are available in a different sizes and styles.</p>
        </div>
    </div>


    <div class="section_content">
        <div class="container">

            <div class="row section_controls">
                <div class="col-12">
                    <ul class="filter-button-groups">
                        <li class="btn active" data-filter="">
                            All
                        </li>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="btn" data-filter=".<?php echo e($service->id); ?>">
                            <?php echo e($service->title); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row gy-3 collections_grid">
                <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-sm-6 col-6 item <?php echo e($collection->Service->id); ?>">
                    <div class="collection_block">
                        <div class="collection_image">
                            <img src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($collection->image); ?>" class="img-fluid w-100" alt="">
                        </div>
                        <div class="collection_content"></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
</section>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    // <!-- on button click -->
    $grid = $(".collections_grid");

    $('.filter-button-groups').on('click', 'li', function() {
        var filterValue = $(this).attr('data-filter');
        // use filterFn if matches value

        $grid.children(".item").hide(100)
        $grid.children(filterValue).show(100)

    });
    // change active button class on buttons
    $('.filter-button-groups').each(function(i, buttonGroup) {
        var $buttonGroup = $(buttonGroup);
        $buttonGroup.on('click', 'li', function() {
            $buttonGroup.find('.active').removeClass('active');
            $(this).addClass('active');
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\TopClass\resources\views/app/index.blade.php ENDPATH**/ ?>