<?php echo e($slot); ?>

<?php /**PATH C:\Users\DevTen\laravel\micagem\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>