

<?php $__env->startSection('title'); ?>
<title><?php echo e($page['page_name']); ?> - <?php echo e($info['company_name']); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="hero" id="active">
    <div class="hero_content wow slideInLeft">
        <h3 class="wow slideInLeft" data-wow-duration="2s" data-wow-delay=".1s"><?php echo e($page->header_text); ?></h3>
        <!-- <h3>Ultimate Flooring & Paving</h3> -->
        <div class="divider wow slideInRight" data-wow-delay="0.2s"></div>
        <p><?php echo e($page->sub_text); ?> </p>
        <div class="">
            <a href="#requestQuote" class="btn primary_bg btn-sm text-white wow slideInLeft" data-wow-duration="2s" data-wow-delay=".4s">About Us</a>
            <span class="mx-2"></span>
            <a href="#requestQuote" class="btn btn-outline-success btn-sm text-white wow slideInRight" data-wow-duration="1s" data-wow-delay=".4s">Request Quote</a>
        </div>
    </div>
</div>
</div>


<section class="about">
    <div class="container">
        <div class="section_title">
            <h3>About <?php echo e($info['company_name']); ?></h3>

            <!-- <h3>We provide quality Flooring Services</h3> -->
            <div class="divider"></div>
            <p>Who we are</p>
        </div>

        <div class="section_content">
            <div class="row">
                <div class="col-md-6">
                    <h3><?php echo e($aboutPage->about_heading); ?></h3>
                    <div class="divider"></div>
                    <div class="about_us_content">
                        <?php echo $aboutPage->about_us; ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about_home_carousel">
                        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <img src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($slide->image); ?>" class="img-fluid w-100" alt="" />
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


</section>

<section class="services">
    <div class="container">
        <div class="section_title">
            <h3>Our Services</h3>
            <!-- <h3>We provide quality Flooring Services</h3> -->
            <div class="divider"></div>
            <p>To many clients like homes and offices</p>
        </div>

        <!-- Rugs, Vinyl Sheet, Vinyl Tile, Carpet, Laminate, Hardwood,  -->
        <div class="section_content mt-3">
            <div class="row gy-3">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6 wow fadeIn" data-wow-delay="0.2s" data-wow-duration="1s">
                    <div class="service_block">
                        <img src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($service->image); ?>" class="img-fluid w-100" alt="">
                        <div class="content">
                            <a href="/collections/<?php echo e($service->title); ?>">
                                <h4><?php echo e($service->title); ?></h4>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>


    </div>
</section>


<section class="collections">
    <div class="container">
        <div class="section_title">
            <h3>Our Portfolio</h3>
            <!-- <h3>We provide quality Flooring Services</h3> -->
            <div class="divider"></div>
            <p>Just a glance into our portfolio.</p>
        </div>
    </div>

    <div class="section_content">
        <div class="container">
            <div class="row gy-3 collections_grid">
                <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-sm-6 col-6 item <?php echo e($collection->Service->id); ?>">
                    <div class="collection_block">
                        <div class="collection_image">
                            <img src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($collection->image); ?>" class="img-fluid w-100" alt="">
                        </div>
                        <div class="collection_content">
                            <div class="section_title mt-2">
                                <h3 class="fs-5">
                                    <?php echo e($collection->title); ?>

                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="section_footer my-5">
                <div class="text-center">
                    <a href="/collections" class="btn primary_bg text-white bg-lg">Go to Portfolio</a>
                </div>
            </div>
        </div>


        <section class="out_team bg-white py-5">
            <div class="container">
                <div class="section_title text-center">
                    <h3 class="wow rubberBand" data-wow-duration="1s" data-wow-delay="0.2s">Our Team</h3>
                    <div class="divider mx-auto divider wow bounceInDown" data-wow-duration="2s" data-wow-delay="0.2s"></div>
                    <p>Meet our team</p>
                </div>
                <div class="our_team_grid">
                    <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card team p-1">
                        <div class="team_image">
                            <?php if(empty($member->image)): ?>
                            <img class="img-fluid" height="300" style="object-fit: cover;" src="/assets/images/user_avatar.jpg" alt="">
                            <?php else: ?>
                            <img class="img-fluid" height="300" style="object-fit: cover;" src="/storage/<?php echo e($member->image); ?>" alt="">
                            <?php endif; ?>
                        </div>
                        <div class="team_name">
                            <h6 class="m-0 pt-2"><?php echo e($member->name); ?></h6>
                            <small><?php echo e($member->post); ?></small>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

        <section class="out_team py-5">
            <div class="container">
                <div class="section_title text-center">
                    <h3 class="wow rubberBand" data-wow-duration="1s" data-wow-delay="0.2s">Our Clients</h3>
                    <div class="divider mx-auto divider wow bounceInDown" data-wow-duration="2s" data-wow-delay="0.2s"></div>
                    <p>Our Clients and Projects Delivered</p>
                </div>
                <div class="row row-cols-2 row-cols-md-3">
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-2">
                        <div class="card p-2" style="min-height: 150px;">
                            <div class="team_name px-2">
                                <!-- <span class="fa-diamond fa"></span> -->
                                <h4 class="m-0 text-dark pt-2 text-center"><?php echo e($client->name); ?></h4>
                                <small class="text-dark"><?php echo e($client->project); ?></small>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
</section>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    // <!-- on button click -->
    $grid = $(".collections_grid");

    $('.filter-button-groups').on('click', 'li', function() {
        var filterValue = $(this).attr('data-filter');
        // use filterFn if matches value

        $grid.children(".item").hide(100)
        $grid.children(filterValue).show(100)

    });
    // change active button class on buttons
    $('.filter-button-groups').each(function(i, buttonGroup) {
        var $buttonGroup = $(buttonGroup);
        $buttonGroup.on('click', 'li', function() {
            $buttonGroup.find('.active').removeClass('active');
            $(this).addClass('active');
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DevTen\laravel\micagem\resources\views/app/index.blade.php ENDPATH**/ ?>