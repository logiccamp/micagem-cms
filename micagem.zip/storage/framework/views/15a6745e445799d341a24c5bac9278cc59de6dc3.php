

<?php $__env->startSection('content'); ?>

<div class="container-fluid settings">
    <div class="row">
        <div class="col-12 m-2">
            <form action="<?php echo e(route('updateService', $service->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-heading py-5">
                        <div class="row justify-content-between align-items-center p-3">
                            <div class="col-md-6 text-center">
                                <h3><?php echo e($service->title); ?></h3>
                            </div>

                            <div class="col-md-6 text-center">
                                <img style="height: 100px; width: 100px" src="/storage/<?php echo e($service->image); ?>" />
                                <div class="form-group my-1">
                                    <label class="w-100 text-center btn bt-gradient bg-secondary" id="addServiceImageLabel" for="addServiceImage">Change</label>
                                    <input type="file" onchange="editserviceImageChange()" id="addServiceImage" class="form-control addServiceImage d-none" placeholder="Enter Service">
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="card-body">
                        <div>
                            <label for="">Title</label>
                            <input type="text" class="form-control" value="<?php echo e($service->title); ?>">
                        </div>
                        <div class="my-4">
                            <label for="">Description</label>
                            <textarea class="form-control" name="description" id="" cols="30" rows="5"><?php echo e($service->description); ?></textarea>
                        </div>
                        <div>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    function editserviceImageChange() {
        alert("Hechange")
    }
    $(document).ready(function() {});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\TopClass\resources\views/admin/editService.blade.php ENDPATH**/ ?>