<?php $__env->startComponent('mail::message'); ?>
# New Quote Request Message

<b>From</b><br>
<?php echo e($data["name"]); ?>

<br>
<b>Email</b><br>
<?php echo e($data["email"]); ?>


<br>
<b>Message</b><br>
<?php echo e($data["message"]); ?>

<br>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\TopClass\resources\views/emails/quotemail.blade.php ENDPATH**/ ?>