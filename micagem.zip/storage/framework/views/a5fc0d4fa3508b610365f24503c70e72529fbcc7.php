

<?php $__env->startSection('content'); ?>
<div class="panel box-shadow-none content-header">
    <div class="panel-body">
        <div class="col-md-12">
            <h3 class="animated fadeInLeft">Settings</h3>
            <p class="animated fadeInDown">
                Home <span class="fa-angle-right fa"></span> Settings
            </p>
        </div>
    </div>
</div>
<div class="container-fluid settings">
    <div class="row">
        <div class="col-md-12">
            <div class="col-md-12 panel">
                <div class="col-md-12 panel-body">
                    <div class="col-md-12">
                        <!-- 
                        name
                        address
                        email
                        tel
                        address
                        
                        logo
                        description
                        facebook, instagram, googleplus, linkedin, twitter -->
                        <div class="col-md-6">
                            <div class="form-group form-animate-text" style="margin-top:40px !important;">
                                <input type="text" disabled class="form-text mask-date" value="<?php echo e($info->company_name); ?>" required>
                                <label>Name</label>
                            </div>

                            <div class="form-group form-animate-text" style="margin-top:40px !important;">
                                <input type="text" disabled class="form-text mask-time" value="<?php echo e($info->company_address); ?>">
                                <label>Address</label>
                            </div>

                            <div class="form-group form-animate-text" style="margin-top:40px !important;">
                                <input type="text" disabled class="form-text mask-time" value="<?php echo e($info->company_address2); ?>">
                                <label>Address 2</label>
                            </div>

                            <div class="form-group form-animate-text" style="margin-top:40px !important;">
                                <input type="text" disabled class="form-text mask-time" value="<?php echo e($info->company_email); ?>">
                                <label>Email</label>
                            </div>

                            <?php if($info->company_email2 != ""): ?>
                            <div class="form-group form-animate-text" style="margin-top:40px !important;">
                                <input type="text" disabled class="form-text mask-time" value="<?php echo e($info->company_email2); ?>">
                                <label>Email 2</label>
                            </div>
                            <?php endif; ?>

                            <div class="form-group form-animate-text" style="margin-top:40px !important;">
                                <input type="text" disabled class="form-text mask-time" value="<?php echo e($info->company_phone); ?>">
                                <label>Telephone</label>
                            </div>

                            <div class="form-group form-animate-text" style="margin-top:40px !important;">
                                <div class="form-text mask-time">
                                    <?php echo e($info->short_description); ?>

                                </div>
                                <label>Short Description</label>
                            </div>

                            <div class="form-group">
                                <a href="/admin/edit-settings" class="btn  btn-gradient btn-success">Edit Settings</a>
                            </div>

                        </div>
                        <div class="col-md-6">
                            <div class="form-group form-animate-text" style="margin-top:40px !important;">
                                <div>
                                    <?php if($info->company_logo == ''): ?>
                                    <img src="/assets/logo-img.png" style="max-width: 200px" alt="">
                                    <?php else: ?>
                                    <img src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($info->company_logo); ?>" style="max-width: 200px" alt="">
                                    <?php endif; ?>
                                </div>
                                <form action="<?php echo e(route('updateLogo')); ?>" method="post" class="my-2" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="file" id="companylogo" class="my-1" name="logo">
                                    <button class="btn btn-default " style="width: 100%; max-width: 200px">Save</button>
                                </form>
                            </div>
                            <?php $__currentLoopData = $social_medials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $handle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group form-animate-text" style="margin-top:10px !important; margin-bottom: 10px">
                                <input type="text" disabled class="form-text mask-phone_us" value="<?php echo e($handle->handle); ?>">
                                <span class="bar"></span>
                                <label> <small><?php echo e($handle->Social->title); ?></small></label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if(count($social_medials) == 0): ?>
                            <a href="/admin/socials" class="btn  btn-gradient btn-success">Add Social Handles</a>
                            <?php else: ?>
                            <a href="/admin/socials" class="btn  btn-gradient btn-default">Update Social Handles</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DevTen\laravel\micagem\resources\views/admin/settings.blade.php ENDPATH**/ ?>