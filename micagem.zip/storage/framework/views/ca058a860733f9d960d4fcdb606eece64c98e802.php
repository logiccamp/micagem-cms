


<?php $__env->startSection('content'); ?>
<div class="container-fluid settings">
    <div class="my-4">
        <div class="row">
            <div class="col-md-6">
                <div class="hero overlay" style='background: url("<?php echo e(env('APP_CDN')); ?>/<?php echo e($banner); ?>")'>
                    <div class="hero_content wow slideInLeft">
                        <h3 class="wow slideInLeft" data-wow-duration="2s" data-wow-delay=".1s"><?php echo e($header_text); ?></h3>
                        <!-- <h3>Ultimate Flooring & Paving</h3> -->
                        <div class="divider wow slideInRight" data-wow-delay="0.2s"></div>
                        <p><?php echo e($sub_text); ?></p>
                    </div>
                </div>
                <div class="d-flex justify-content-center my-3">
                    <input onchange="bannerChange()" type="file" accept=".png, .jpg" class="d-none homeBg" id="homeBg" hidden>
                    <Label class="btn btn-primary" for="homeBg">Change Background</Label>
                </div>
            </div>
            <div class="col-md-6">
                <form action="<?php echo e(route('updateHomeBanner')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="my-3">
                        <label for="">Header text</label>
                        <input type="text" class="form-control" value="<?php echo e($header_text); ?>" require name="header_text">
                    </div>

                    <div class="my-3">
                        <label for="">Header Sub-text</label>
                        <input type="text" class="form-control" value="<?php echo e($sub_text); ?>" require name="header_sub_text">
                        <input type="text" hidden class="form-control d-none" value="<?php echo e($page_name); ?>" require name="page_name">
                    </div>

                    <div class="my-3">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
            <hr>
        </div>



    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    function bannerChange() {
        if (!$(".homeBg")[0].files[0]) {

            return false;
        }
        const file = $(".homeBg")[0].files[0]
        var formdata = new FormData();
        formdata.append("banner", file)
        formdata.append("page", '<?php echo e($page_name); ?>')
        fetch("<?php echo e(route('changeHomeBanner')); ?>", {
                method: 'POST',
                body: formdata,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            })
            .then((response) => response.json())
            .then((response) => {
                window.location.reload();
            })
        console.log(file)
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DevTen\laravel\micagem\resources\views/admin/home.blade.php ENDPATH**/ ?>