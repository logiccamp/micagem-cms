<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Welcome to <?php echo e($info['company_name']); ?>, furnishings and global designs limited ,your number one source for all kinds of wall to wall carpet , window blinds, artificial grass carpet , center rugs, Armstrong pvc carpet.">
    <meta name="keywords" content="Carptets, Rug, PVC, Flooring">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php echo $__env->yieldContent('title'); ?>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/flaticon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/main.css')); ?>" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(env('APP_CDN')); ?>/<?php echo e($info->company_logo); ?>" type="image/x-icon">
</head>

<body>
    <div id="app">
        <div class="banner overlay" id="<?php echo e($page->page_name !== 'Home' ? 'page' : ''); ?>" style='background-repeat: no-repeat; background-position: center !important; background: url("<?php echo e(env('APP_CDN')); ?>/<?php echo e($page->banner); ?>")'>
            <header class="px-lg-3">
                <nav class="navbar navbar-expand-lg navbar-dark bg-none py-3">
                    <a class="navbar-brand" href="#"><img style="height: 72px" class="img-fluid" src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($info->company_logo); ?>" alt=""></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-0">
                            <li class="nav-item <?php echo e($active == 'Home' ? 'active' : ''); ?>">
                                <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item <?php echo e($active == 'About' ? 'active' : ''); ?>">
                                <a class="nav-link" href="/about-us">About</a>
                            </li>

                            <li class="nav-item <?php echo e($active == 'Services' ? 'active' : ''); ?>">
                                <a class="nav-link" href="/services">Services</a>
                            </li>

                            <li class="nav-item <?php echo e($active == 'Portfolio' ? 'active' : ''); ?>">
                                <a class="nav-link" href="/portfolio">Portfolio</a>
                            </li>
                            <li class="nav-item <?php echo e($active == 'Team' ? 'active' : ''); ?>">
                                <a class="nav-link" href="/teams">Our Team</a>
                            </li>
                            <li class="nav-item <?php echo e($active == 'Contact' ? 'active' : ''); ?>">
                                <a class="nav-link" href="/contact">Contact</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>

            <?php echo $__env->yieldContent("main"); ?>

            <section class="testimonial_quote last">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 tesimonials">
                            <div class="section_title">
                                <h2>Client Feedback</h2>
                            </div>
                            <div class="section_content">
                                <div class="divider mb-5"></div>
                                <?php if(count($testimonials) > 1): ?>
                                <div class="tesimonials_slider">
                                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="testimonial">
                                        <div class="testimonial_content">
                                            <p><?php echo e($testimonial->message); ?></p>
                                        </div>
                                        <div class="testimonial_user mt-5">
                                            <h6 class="m-0"><?php echo e($testimonial->name); ?></h6>
                                            <small class="primary_color"><?php echo e($testimonial->post); ?> of <?php echo e($testimonial->company); ?></small>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php else: ?>
                                <div class="tesimonials_slier">
                                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="testimonial">
                                        <div class="testimonial_content">
                                            <p><?php echo e($testimonial->message); ?></p>
                                        </div>
                                        <div class="testimonial_user mt-5">
                                            <h6 class="m-0"><?php echo e($testimonial->name); ?></h6>
                                            <small class="primary_color"><?php echo e($testimonial->post); ?> of <?php echo e($testimonial->company); ?></small>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6 request_quote" id="requestQuote">
                            <div class="section_title">
                                <h2>Get a free Quote</h2>
                            </div>
                            <div class="section_content">
                                <div class="divider mb-5"></div>
                                <div class="quote_box">
                                    <div class="quote_head">
                                        <p>We are waiting for your message .</p>
                                    </div>
                                    <div class="quote_content">
                                        <form action="<?php echo e(route('submitQuote')); ?>" method="POST" class="form">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="form-group col-6 my-2">
                                                    <input type="text" class="form-control" placeholder="Your Name" name="quotename">
                                                </div>
                                                <div class="form-group col-6 my-2">
                                                    <input type="text" class="form-control" placeholder="Your Email" name="quoteemail">
                                                </div>
                                                <div class="form-group col-12 my-2">
                                                    <textarea name="quotemessage" class="form-control" placeholder="Your message" id="" cols="30" rows="5"></textarea>
                                                </div>
                                                <div class="form-group col-12 my-2">
                                                    <button class="btn primary_bg text-white">Submit</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </section>
            <footer class="bg-dark py-5">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="theme1_footerdiv wow fadeInUp" data-wow-delay="0.5s">
                                <a href="/"><img style="height: 100px" src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($info->company_logo); ?>" class="" alt="herbal-pure-footer-logo"></a>
                                <p><?php echo e($info->short_description); ?></p>
                                <div class="theme1_social_icon mx-0">
                                    <ul style="padding-inline-start: 0;">
                                        <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $handle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($handle->handle); ?>" class="wow fadeIn" data-wow-delay="0.8s"><i class="fa fa-<?php echo e(strtolower($handle->social->title)); ?>"></i></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <!-- <li><a href="#" class="wow fadeIn" data-wow-delay="1s"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#" class="wow fadeIn" data-wow-delay="1.2s"><i class="fa fa-google-plus"></i></a></li>
                                        <li><a href="#" class="wow fadeIn" data-wow-delay="1.4s"><i class="fa fa-linkedin"></i></a></li> -->
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="theme1_footerdiv text-center wow fadeInUp" data-wow-delay="0.5s">
                                <h3>Links</h3>
                                <ul class="theme1_footer_links p-0">
                                    <li>
                                        <p><a href="#">Home</a></p>
                                    </li>
                                    <li>
                                        <p><a href="#">About</a></p>
                                    </li>
                                    <li>
                                        <p><a href="#">Portfolio</a></p>
                                    </li>
                                    <li>
                                        <p><a href="#">Gallery</a></p>
                                    </li>
                                    <li>
                                        <p><a href="#">Contact Us</a></p>
                                    </li>

                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="theme1_footerdiv wow fadeInUp" data-wow-delay="0.5s">
                                <h3>Get in Touch</h3>
                                <ul class="theme1_footer_contact p-0">
                                    <li>
                                        <span><i class="fa fa-envelope"></i></span>
                                        <p>
                                            <a href="#"><?php echo e($info->company_email); ?></a>
                                            <?php if($info->company_email2 != ""): ?>
                                            , <a href="tel:<?php echo e($info->company_email2); ?>"><?php echo e($info->company_email2); ?></a>
                                            <?php endif; ?>
                                        </p>
                                    </li>
                                    <li>
                                        <span><i class="fa fa-phone"></i></span>
                                        <p><?php echo e($info->company_phone); ?></p>
                                    </li>
                                    <li>
                                        <span><i class="fa fa-home"></i></span>
                                        <p><?php echo e($info->company_address); ?></p>
                                    </li>
                                    <?php if($info->company_address2 != ""): ?>
                                    <li>
                                        <span><i class="fa fa-home"></i></span>
                                        <p><?php echo e($info->company_address2); ?></p>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </footer>
            <div class="copyright_wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <p>Copyright © <?php echo e(date('Y')); ?> <a class="text-white" href="/admin"><?php echo e($info->company_name); ?></a>, All Rights Reserved by <a target="_blank" href="//logiccamp.com.ng">Logic Software Solutions</a>.</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>


        <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/owl.carousel.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/isotope.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
        <script src="//code.tidio.co/mmugeyvpuzaqbikbnzlcpwcbschhj40a.js" async></script>
        <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html><?php /**PATH C:\Users\DevTen\laravel\micagem\resources\views/layouts/app.blade.php ENDPATH**/ ?>