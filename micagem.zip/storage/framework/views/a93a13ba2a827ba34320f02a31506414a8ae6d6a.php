

<?php $__env->startSection('title'); ?>
<title>Contact Us - <?php echo e($info['company_name']); ?></title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>


<div class="hero" id="<?php echo e($active); ?>">
    <div class="hero_content wow slideInLeft">
        <h3 class="wow slideInLeft" data-wow-duration="2s" data-wow-delay=".1s">CONTACT US</h3>
        <!-- <h3>Ultimate Flooring & Paving</h3> -->
        <div class="divider wow slideInRight" data-wow-delay="0.2s"></div>
    </div>
</div>
</div>

<section class="contact_us">
    <div class="container">
        <p class="fs-6">Thank you for your interest in the <?php echo e($info['company_name']); ?>. Please fill out the form below to ask a question, leave a statement or to report a technical problem and we will get back to you at our earliest convenience.</p>
    </div>

    <div class="container my-5">
        <div class="row gx-4 gy-4">
            <div class="col-md-4">
                <div class="card text-center p-3 py-5">
                    <i class="fa fa-home fa-3x primary_color"></i>
                    <h4>Our Address</h4>
                    <p class="w-75 mx-auto"><?php echo e($info->company_address); ?></p>
                    <?php if($info->company_email2 != ""): ?>
                    <p><?php echo e($info->company_email2); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card text-center p-3 py-5">
                    <i class="fa fa-envelope fa-3x primary_color"></i>
                    <h4>Phone and Email</h4>
                    <p><?php echo e($info->company_phone); ?> <br />
                        <?php echo e($info->company_email); ?>

                        <?php if($info->company_email2 != ""): ?>
                        <br /> <?php echo e($info->company_email2); ?>

                        <?php endif; ?>
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card text-center p-3 py-5">
                    <i class="fa fa-share fa-3x primary_color"></i>
                    <h4>Social Media</h4>
                    <p>Join us on social media </p>
                    <p class="social_media my-1">
                        <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($social->handle); ?>" target="_blank">
                            <i class="fa fa-<?php echo e(strtolower($social->social->title)); ?>"></i>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="map_contact py-5 last bg-white">
    <div class="container">
        <div class="row gy-5 flex-column-reverse">
            <div class="col-12 map">
                <div class="section_title">
                    <h2>Our Location</h2>
                </div>
                <div class="section_content">
                    <div class="divider mb-5"></div>
                    <div class="location">
                        <div class="map_content">
                            <iframe src="https://maps.google.com/maps?q=59+Ikorodu+Road,+Fadeyi,+Lagos,+Nigeria&output=embed" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 request_quote">
                <div class="section_title">
                    <h2 class="text-dark">Contact Us</h2>
                </div>
                <div class="section_content">
                    <div class="divider mb-5"></div>
                    <div class="quote_box">
                        <div class="quote_head">
                            <p>We are waiting for your message :)</p>
                        </div>
                        <div class="quote_content">
                            <form action="<?php echo e(route('contactMessage')); ?>" method="POST" class="form">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="form-group col-6 my-2">
                                        <input type="text" name="contactname" class="form-control" placeholder="Your Name">
                                    </div>
                                    <div class="form-group col-6 my-2">
                                        <input type="text" name="contactemail" class="form-control" placeholder="Your Email">
                                    </div>
                                    <div class="form-group col-12 my-2">
                                        <input type="text" name="contactphone" class="form-control" placeholder="Your Telephone">
                                    </div>
                                    <div class="form-group col-12 my-2">
                                        <textarea name="contactmessage" class="form-control" placeholder="Your message" id="" cols="30" rows="5"></textarea>
                                    </div>
                                    <div class="form-group col-12 my-2">
                                        <button class="btn primary_bg text-white">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <br>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DevTen\laravel\micagem\resources\views/app/contact.blade.php ENDPATH**/ ?>