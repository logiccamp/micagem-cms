

<?php $__env->startSection('title'); ?>
<title>Team - <?php echo e($info['company_name']); ?></title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>


<div class="hero" id="<?php echo e($active); ?>">
    <div class="hero_content wow slideInLeft">
        <h3 class="wow slideInLeft" data-wow-duration="2s" data-wow-delay=".1s">Our Team</h3>
        <!-- <h3>Ultimate Flooring & Paving</h3> -->
        <div class="divider wow slideInRight" data-wow-delay="0.2s"></div>
    </div>
</div>
</div>


<section class="collections">
    <div class="container">
        <div class="section_title">
            <h3>Our Team</h3>
            <!-- <h3>We provide quality Flooring Services</h3> -->
            <div class="divider"></div>
            <p>Meet our team.</p>
        </div>
    </div>


    <div class="section_content">
        <div class="container">

        </div>
        <div class="container-fluid">
            <div class="row gy-3 collections_grid">
                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-sm-6 col-6">
                    <div class="team p-1 shadow p-3 bg-white rounded">
                        <div class="team_image mx-auto text-center">
                            <img class="img-fluid rounded-pill" height="250" width="250" style="object-fit: cover;" src="/storage/<?php echo e($member->image); ?>" alt="">
                        </div>
                        <div class="team_name text-center">
                            <h6 class="m-0 pt-2 text-black"><?php echo e($member->name); ?></h6>
                            <small><?php echo e($member->post); ?></small>
                            <p><?php echo e($member->description); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


</section>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<!-- init isotope -->
<script>
    // <!-- on button click -->
    $grid = $(".collections_grid");

    $('.filter-button-groups').on('click', 'li', function() {
        var filterValue = $(this).attr('data-filter');
        // use filterFn if matches value

        $grid.children(".item").hide(100)
        $grid.children(filterValue).show(100)

    });
    // change active button class on buttons
    $('.filter-button-groups').each(function(i, buttonGroup) {
        var $buttonGroup = $(buttonGroup);
        $buttonGroup.on('click', 'li', function() {
            $buttonGroup.find('.active').removeClass('active');
            $(this).addClass('active');
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DevTen\laravel\micagem\resources\views/app/team.blade.php ENDPATH**/ ?>