


<?php $__env->startSection('content'); ?>
<div class="panel box-shadow-none content-header" style="position: relative;">
    <div class="panel-body">
        <div class="col-md-12">
            <div class="d-flex justify-content-between">
                <div>
                    <h3 class="animated fadeInLeft">About Us Page </h3>
                    <p class="animated fadeInDown">
                        Home <span class="fa-angle-right fa"></span> Pages <span class="fa-angle-right fa"></span> About
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid settings">
    <div class="my-4">

        <div class="my-3 card p-3">
            <legend>Slides</legend>
            <form action="<?php echo e(route('addAboutSlide')); ?>" method="POST" class="form py-3" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="slide" id="slide" require class="form-control" />
                <button class="btn primary_btn">Add</button>
            </form>
            <div class="d-flex" style="flex-wrap:wrap">
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="px-3">
                    <img height="100" src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($slide->image); ?>" class="img-fluid" alt="">
                    <form action="<?php echo e(route('deleteSlide', $slide->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="w-100 btn">&times;</button>
                    </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <br>
        <form action="">
            <legend>About Content</legend>
            <div class="row px-4">
                <div class="col-md-6">
                    <input type="text" id="about_heading" class="form-control" value="<?php echo e($about->about_heading); ?>" />
                </div>
                <hr>
                <div class="col-md-12">
                    <div id="summernote"><?php echo $about->about_us; ?></div>
                </div>
                <div class="col-md-12">
                    <button id="aboutContent" class="btn btn-success">Update</button>
                </div>
            </div>
        </form>
        <br />
        <div class="my-3">
            <legend>Our Mission</legend>
            <div class="row px-4">
                <div class="col-md-6 my-3">
                    <form action="<?php echo e(route('missionContent')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <textarea id="our_mission" name="mission" class="form-control" rows="10"><?php echo e($about->mission); ?></textarea>
                        <div class="col-md-12">
                            <button id="aboutContent" class="btn btn-success">Update</button>
                        </div>
                    </form>
                </div>

                <div class="col-md-6 my-3">
                    <img src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($about->mission_banner); ?>" class="form-control" style="height: 200px; width: 100%; object-fit: contain" />
                    <div>
                        <form action="<?php echo e(route('updateMissionBanner')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="file" required id="mission_banner" accept=".png, .jpg, .jpeg" name="missionBanner" class="form-control my-3" />
                            <button type="submit" class="btn btn-default">Change</button>
                        </form>
                    </div>
                </div>
                <hr>
            </div>
        </div>


        <br />
        <div class="my-3">
            <legend>Our Vision</legend>
            <div class="row px-4">
                <div class="col-md-6 my-3">
                    <form action="<?php echo e(route('visionContent')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <textarea id="our_vision" name="vision" class="form-control" rows="10"><?php echo e($about->vision); ?></textarea>
                        <div class="col-md-12">
                            <button id="aboutContent" class="btn btn-success">Update</button>
                        </div>
                    </form>
                </div>

                <div class="col-md-6 my-3">
                    <img src="<?php echo e(env('APP_CDN')); ?>/<?php echo e($about->vision_banner); ?>" class="form-control" style="height: 200px; width: 100%; object-fit: contain" />
                    <div>
                        <form action="<?php echo e(route('updateVisionBanner')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="file" required id="vision_banner" accept=".png, .jpg, .jpeg" name="visionBanner" class="form-control my-3" />
                            <button type="submit" class="btn btn-default">Change</button>
                        </form>
                    </div>
                </div>
                <hr>
            </div>
        </div>



    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $("#summernote").summernote({
        height: 200
    })

    function missionBanner() {
        alert("hello")
    }

    $("#aboutContent").on("click", function(e) {
        e.preventDefault();

        const summernote = $(".note-editable")[0].outerHTML
        var note = summernote.replace('contenteditable="true" style="height: 200px;" spellcheck="false"', '')
        note = note.replace('<div class="note-editable panel-body" contenteditable="true" style="height: 200px;">', '')
        note = note.replace('<div class="note-editable panel-body" contenteditable="true" style="height: 200px;" spellcheck="true">', '')
        note = note.replace('<div class="note-editable panel-body" >', '')
        note = note.replace('</div>', '')
        console.log(note)
        var formdata = new FormData();
        formdata.append("about_heading", $("#about_heading").val())
        formdata.append("content", note)

        fetch("<?php echo e(route('updateAboutContent')); ?>", {
                method: 'POST',
                body: formdata,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            })
            .then((response) => response.json())
            .then((response) => {
                window.location.reload();
            })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\TopClass\resources\views/admin/about.blade.php ENDPATH**/ ?>