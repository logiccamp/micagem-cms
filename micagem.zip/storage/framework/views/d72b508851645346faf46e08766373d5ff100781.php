


<?php $__env->startSection('content'); ?>
<div id="ontent" class="bg-dark">
    <div style="height: 400px; flex-direction: column; display: flex; justify-content: center; align-items: center">
        <h4>Welcome:</h4>
        <h1>Admin</h1>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DevTen\laravel\micagem\resources\views/admin/index.blade.php ENDPATH**/ ?>