

<?php $__env->startSection('content'); ?>
<div id="content" style="padding: 0; margin: 0;">
    <div class="container-fluid">
        <div class="mt-5 row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3>Account Security</h3>
                    </div>
                    <?php if(Session::has('message')): ?>
                    <?php if(Session::get('message') == "success"): ?>
                    <div class="alert alert-success">
                        <p><?php echo e(Session::get('message')); ?></p>
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <p><?php echo e(Session::get('message')); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                    <div class="card-body">
                        <form action="<?php echo e(route('updatePassword')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Current Password</label>
                                <input type="password" name="oldpassword" required class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="">New Password</label>
                                <input type="password" name="password" required class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="">Confirm Password</label>
                                <input type="password" name="password_confirmation" required class="form-control">
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-success">Save</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>

            <div class="col-md-6" style="display: none;">
                <div class="card">
                    <div class="card-header">
                        <h3>All Users</h3>
                    </div>

                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->status); ?></td>
                                    <td>
                                        <form action="" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php if(auth()->user()->email == "admin@topclasscarpets.com"): ?>
                                            <button class="btn btn-success" type="submit">&times;</button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yemi Maxedge\laravel\TopClass\resources\views/generals/index.blade.php ENDPATH**/ ?>