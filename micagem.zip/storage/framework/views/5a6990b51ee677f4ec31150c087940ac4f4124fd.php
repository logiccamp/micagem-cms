

<?php $__env->startSection('content'); ?>
<div class="panel box-shadow-none content-header">
    <div class="panel-body">
        <div class="col-md-12">
            <h3 class="animated fadeInLeft">Social Media </h3>
            <p class="animated fadeInDown">
                Home <span class="fa-angle-right fa"></span> Social Media
            </p>
        </div>
    </div>
</div>
<div class="container-fluid settings">
    <div class="row">
        <div class="col-md-12">
            <div class="col-md-12">
                <div class="col-md-12">
                    <div class="col-md-12">
                        <div class="col-md-6">
                            <div class="card p-2 h-100">
                                <?php if(Session::has('message')): ?>
                                <p class="text-danger"><?php echo e(Session::get('message')); ?></p>
                                <?php endif; ?>
                                <p></p>
                                <h3 class="text-center">ADD NEW</h3>
                                <form action="<?php echo e(route('addSocial')); ?>" method="POST" class="form p-3">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="social" class="form-control" placeholder="Enter Social media name">
                                    <button class="btn my-3 btn-gradient btn-default">Add New</button>
                                </form>
                                <div>
                                    <table class="table table-stripped">
                                        <thead>
                                            <tr>
                                                <th align="center">Name</th>
                                                <th align="center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $allSocials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <strong><?php echo e($social->title); ?></strong>
                                                </td>
                                                <td align="center">
                                                    <form action="<?php echo e(route('deleteSocial')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="text" value="<?php echo e($social->id); ?>" hidden name="social">
                                                        <button class="btn btn-danger text-danger">&times;</button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <form action="<?php echo e(route('updateSocial')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <ul class="card p-3">
                                    <?php $__currentLoopData = $allSocials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="my-2 p-2">
                                        <strong><?php echo e($social->title); ?></strong>
                                        <input type="text" value="<?php echo e($social->Handle == null ? '' : $social->Handle->handle); ?>" name="<?php echo e($social->id); ?>" class="form-control" placeholder="Paste your link here">
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button class="btn w-100 btn-gradient btn-success"> Save </button>
                                </ul>
                            </form>
                        </div>
                        <div class="col-md-6">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DevTen\laravel\micagem\resources\views/admin/socials.blade.php ENDPATH**/ ?>