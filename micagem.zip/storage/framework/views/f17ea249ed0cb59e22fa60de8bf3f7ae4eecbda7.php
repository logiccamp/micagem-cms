

<?php $__env->startSection('content'); ?>
<div class="panel box-shadow-none content-header" style="position: relative;">
    <div class="panel-body">
        <div class="col-md-12">
            <div class="d-flex justify-content-between">
                <div>
                    <h3 class="animated fadeInLeft"><?php echo e(isset($team) ? 'Edit Team' : 'Add Team'); ?> </h3>
                    <p class="animated fadeInDown">
                        Home <span class="fa-angle-right fa"></span> <?php echo e(isset($team) ? 'Edit Team' : 'Add Team'); ?>

                    </p>
                </div>
                <div>
                    <h3>
                        <a href="/admin/team/">go back</a>
                    </h3>
                </div>

            </div>
        </div>
    </div>
</div>
<div class="container-fluid settings">
    <div class="row">
        <div class="col-12 m-2">
            <div class="card">
                <div class="card-heading py-5">

                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($team) ? route('updateTeam', $team->id) : route('addTeam')); ?>" class="form" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex align-items-center justify-content-end">
                            <button type="submit" class="btn btn-gradient btn-success"><?php echo e(isset($team) ? 'Update' : 'Add Team'); ?></button>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="">Name</label>
                                <input id="name" value="<?php echo e(isset($team) ? $team->name : ''); ?>" type="text" require name="name" id="" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Post <small>[optional]</small></label>
                                <input id="post" type="text" name="post" value="<?php echo e(isset($team) ? $team->post : ''); ?>" id="" class="form-control">
                            </div>

                            <div class="form-group col-md-6">
                                <label for="">Picture</label>
                                <?php if(isset($team)): ?>
                                <input type="file" class="form-control" name="image" id="" class="form-group">
                                <?php else: ?>
                                <input required type="file" class="form-control" name="image" id="" class="form-group">
                                <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Information</label>
                                <textarea required name="description" id="" cols="30" rows="10" class="form-control"><?php echo e(isset($team) ? $team->description : ''); ?></textarea>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DevTen\laravel\micagem\resources\views/admin/addTeam.blade.php ENDPATH**/ ?>