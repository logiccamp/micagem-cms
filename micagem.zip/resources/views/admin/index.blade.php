@extends("layouts.admin")


@section('content')
<div id="ontent" class="bg-dark">
    <div style="height: 400px; flex-direction: column; display: flex; justify-content: center; align-items: center">
        <h4>Welcome:</h4>
        <h1>Admin</h1>
    </div>
</div>
@endsection