<!-- company's details -->

name
address
description
logo
email
tel
address
facebook, instagram, googleplus, linkedin, twitter
